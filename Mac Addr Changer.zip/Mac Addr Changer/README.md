This package is not obfuscated, so you can view/edit the code how you want.
If you edit the files, you CAN NOT share the file, it's only supposed to be shared in its original form 
or downloaded straight from github.

License is included in this directory.